ADMIN = 'admin'
DEFAULT = 'default'
READWRITE = 'rw'
READ = 'r'
ROLE = 'role'


#{$or: [{'devices.rw':'DT003'},{'devices.r':'DT003'}]}